from tkinter import Tk
from tkinter import Label
from tkinter import Entry
from tkinter import Button
from tkinter import StringVar

from pytube import YouTube

# 用来存储URL输入框中输入的地址
LINK = None


def download_video():
    """下载视频"""
    print("点击【开始下载】按钮后这个函数会被执行...")
    url = LINK.get()
    print("要下载的视频地址是：", url)
    youtube_downloader = YouTube(url)
    video = youtube_downloader.streams.first()
    video.download()
    print("下载完成...")


def main():
    """控制程序整体流程"""
    root = Tk()
    root.geometry('500x300')
    root.resizable(0, 0)
    root.title("www.itprojects.cn-YouTuBe视频下载程序")

    Label(root, text='YouTuBe视频下载程序', font='arial 20 bold').pack()
    Label(root, text='粘贴要下载的视频地址:', font='arial 15 bold').place(x=160, y=60)

    # link_enter = Entry(root, width=70).place(x=2, y=90)
    global LINK
    LINK = StringVar()
    link_enter = Entry(root, width=70, textvariable=LINK).place(x=2, y=90)

    Button(root, text='开始下载', font='arial 15 bold', bg='pale violet red', padx=2, command=download_video).place(x=180, y=150)

    root.mainloop()


if __name__ == '__main__':
    main()
