import datetime
import time
import math
import winsound
from tkinter import *

# 定义全局变量，用来存储时间
hour = None
minute = None
second = None
# 定义全局变量，用来存储要显示的提示信息
tips_label = None


def play_sound():
    """播放提示音"""
    s = """3345 1233345 234 431 434 -612 12334567 +1+1345 23434+1+1
        23434+2+2 +17+1+2+3+277+1 +175516 651132 345+17+1+2+3+2 77+1+175516
        655+17+1
        """
    freq = 440
    i = 0
    while i < len(s):
        c = s[i]
        if str.isspace(s[i]):
            i += 1
            continue
        # print(c)
        if c == '+':
            c = int(s[i + 1]) - 6 + 7
            i += 2
        elif c == '-':
            c = int(s[i + 1]) - 7 - 6
            i += 2
        else:
            c = int(s[i]) - 6
            i += 1
        f = int(freq * math.pow(2, 1 / 7 * c))
        winsound.Beep(f, 500)


def alarm(set_alarm_timer):
    while True:
        time.sleep(1)
        current_time = datetime.datetime.now()
        now = current_time.strftime("%H:%M:%S")
        date = current_time.strftime("%d/%m/%Y")
        print("当前时间是:", date, now)
        if now == set_alarm_timer:
            print("时间到...")
            play_sound()
            break


def actual_time():
    """点击设置闹钟按钮后，要执行的代码"""
    print("点击了按钮...")
    print("时分秒是：", hour.get(), minute.get(), second.get())
    if not all([hour.get(), minute.get(), second.get()]):
        tips_label.place(x=260, y=30)
        return
    tips_label.place_forget()
    alarm_time = "%s:%s:%s" % (hour.get(), minute.get(), second.get())
    alarm(alarm_time)


def main():
    global tips_label

    clock = Tk()
    clock.title("it项目示例网www.itprojects.cn 闹钟")  # 设置窗口的title
    clock.geometry("400x200")  # 设置窗口的宽度与高度

    add_time = Label(clock, text="时  分   秒", font=60).place(x=110)

    # 创建3个变量，用来存储输入的时间
    global hour, minute, second
    hour = StringVar()
    minute = StringVar()
    second = StringVar()

    hour_time = Entry(clock, textvariable=hour, bg="pink", width=15).place(x=110, y=30)
    min_time = Entry(clock, textvariable=minute, bg="pink", width=15).place(x=150, y=30)
    sec_time = Entry(clock, textvariable=second, bg="pink", width=8).place(x=200, y=30)
    tips_label = Label(clock, text="请输入闹钟时间!")

    # 设定闹钟按钮
    submit = Button(clock, text="设置闹钟", fg="red", width=10, command=actual_time).place(x=130, y=70)

    clock.mainloop()  # 程序主循环，像检测按钮的点击等都在这里进行操作


if __name__ == '__main__':
    main()
