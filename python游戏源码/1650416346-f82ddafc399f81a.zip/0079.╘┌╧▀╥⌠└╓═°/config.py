# -*- coding=utf-8 -*-
import os
class Config:
    SECRET_KEY = 'mrsoft'
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    @staticmethod
    def init_app(app):
        pass


basedir = os.path.abspath(os.path.dirname(__file__))

# the config for development
class DevelopmentConfig(Config):
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'data.sqlite')+'?check_same_thread=False'
    DEBUG = True

# define the config
config = {
    'default': DevelopmentConfig
}
