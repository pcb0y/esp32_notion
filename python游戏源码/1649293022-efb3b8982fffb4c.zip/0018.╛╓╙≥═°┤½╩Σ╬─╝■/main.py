import os
import json
import threading
from tkinter import *
import tkinter as tk
import tkinter.messagebox

import psutil
import qrcode
from PIL import ImageTk
from flask import Flask, render_template, request, send_file

COUNT = 0
CHOOSE = 0
QR_CODE = None
CURRENT_IP = None
IP_LIST = 0
LEN_LIST = 0

app = Flask(__name__, template_folder="./templates")


def get_name_by_every_dir(file_dir):
    file_name_with_path = []
    file_name = []
    file_dir_list = []
    for root, dirs, files in os.walk(file_dir):
        for file in files:
            file_name_with_path.append(os.path.join(root, file))  # 保存图片路径
            file_name.append(file)  # 保存图片名称
            file_dir_list.append(root[len(file_dir):])  # 保存图片所在文件夹
    return file_name, file_name_with_path, file_dir_list


def get_query_parameters(file_name_list, file_name_with_path_list):
    file_name_with_query_parameters_list = list()
    for i, temp_file in enumerate(file_name_with_path_list):
        temp_file = temp_file.replace("\\", "/")
        path_list = temp_file.split("/")
        start_index = path_list.index("share_folder") + 1
        stop_index = path_list.index(file_name_list[i])

        query_parameter = "/".join(path_list[start_index: stop_index])
        if query_parameter:
            file_path_temp = file_name_list[i] + "?path=" + query_parameter
        else:
            file_path_temp = file_name_list[i]
        file_name_with_query_parameters_list.append(file_path_temp)

    return file_name_with_query_parameters_list


@app.route('/')
def index():
    """首页"""
    filepath = os.path.join(os.path.dirname(os.path.abspath('__file__')), 'share_folder\\')
    if not os.path.exists(filepath):
        os.makedirs(filepath)
    file_name, file_name_with_path, file_dir = get_name_by_every_dir(filepath)
    file_name = get_query_parameters(file_name, file_name_with_path)
    page = 1
    page_size = 10
    start = (page - 1) * page_size
    end = page * page_size if len(file_name) > page * page_size else len(file_name)
    file_list = [file_name[i] for i in range(start, end)]
    all_page = int(len(file_name) / page_size) + 1
    return render_template('up_load.html', file_list=file_list, all_file=len(file_name), pages=page, all_page=all_page)


@app.route('/next_page/<int:page>/', methods=['GET'])
def next_page(page):
    filepath = os.path.join(os.path.dirname(os.path.abspath('__file__')), 'share_folder\\')
    if not os.path.exists(filepath):
        os.makedirs(filepath)
    file_name, file_name_with_path, file_dir = get_name_by_every_dir(filepath)
    page_size = 10
    all_page = int(len(file_name) / page_size) + 1
    pages = int(page)
    if pages <= 0:
        pages = 1
    elif pages >= all_page:
        pages = int(all_page)
    else:
        pages = int(page)
    start = (pages - 1) * page_size
    end = pages * page_size if len(file_name) > pages * page_size else len(file_name)
    file_list = [file_name[i] for i in range(start, end)]

    return render_template('up_load.html', file_list=file_list, all_file=len(file_name), pages=pages, all_page=all_page)


@app.route('/files/<file_name>', methods=['GET'])
def files(file_name):
    path = request.args.get('path')
    try:
        path = 'share_folder/' + path if path else 'share_folder'
        filepath = os.path.join(os.path.dirname(os.path.abspath('__file__')), path)
        if not os.path.exists(filepath):
            os.makedirs(filepath)
        file = os.path.join(filepath, file_name)
        return send_file(file)
    except Exception as e:
        return json.dumps({'code': "502"}, ensure_ascii=False)


@app.route('/up_load', methods=['post'])
def up_video():
    """上传视频"""
    try:
        filepath = os.path.join(os.path.dirname(os.path.abspath('__file__')), 'share_folder')
        if not os.path.exists(filepath):
            os.makedirs(filepath)
        for f in request.files.getlist('file'):
            if f and '/' in f.filename:
                # print('这是文件夹')
                temp_path = filepath + os.sep + f.filename.split('/')[0]
                if not os.path.exists(temp_path):
                    os.makedirs(temp_path)
                filename = f.filename.split('/')[1]
                upload_path = os.path.join(temp_path, filename)
                f.save(upload_path)
            elif f:
                # print('这是多文件')
                filename = f.filename
                upload_path = os.path.join(filepath, filename)
                f.save(upload_path)
            else:
                continue
        return render_template('up_load_ok.html')
    except Exception as e:
        # print(e)
        return json.dumps({'code': "502"}, ensure_ascii=False)


def run_sever():
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)


def qrc_img(url):
    qr = qrcode.QRCode(version=2, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=11, border=2, )
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image()
    return img


def start():
    global QR_CODE, CURRENT_IP, COUNT, IP_LIST, LEN_LIST, CHOOSE
    if CHOOSE == 0:
        thread = threading.Thread(target=run_sever)  # 创建一个线程运行服务器
        thread.setDaemon(True)
        thread.start()  # 运行线程
        CURRENT_IP.config(text=IP_LIST[COUNT])
        img = qrc_img(IP_LIST[COUNT])
        IMG = ImageTk.PhotoImage(img)
        QR_CODE.config(image=IMG)
        QR_CODE.image = IMG
        COUNT += 1
        CHOOSE = 1
        tkinter.messagebox.showinfo('成功', '已开启服务！')
    else:
        tkinter.messagebox.showinfo('提示', '服务已运行！')


def get_ip():
    """获取ipv4地址"""
    dic = psutil.net_if_addrs()
    ipv4_list = []
    for adapter in dic:
        # 网线端口：以太网，wifi端口：WLAN
        if 'Eth' in adapter or '以太' in adapter or 'WLAN' in adapter:
            snicList = dic[adapter]
            for snic in snicList:
                if snic.family.name == 'AF_INET':
                    ipv4 = snic.address
                    if ipv4 != '127.0.0.1':
                        ipv4_list.append("http://" + ipv4 + ":5000")
    if len(ipv4_list) >= 1:
        return ipv4_list[::-1], len(ipv4_list)
    else:
        return []


def show_qrc():
    global QR_CODE, CURRENT_IP, COUNT, IP_LIST, LEN_LIST, CHOOSE
    if CHOOSE == 0:
        tkinter.messagebox.showinfo('警告', '请先开启服务！')
    else:
        if COUNT < LEN_LIST:
            # print(IP_LIST[COUNT])
            CURRENT_IP.config(text=IP_LIST[COUNT])
            img = qrc_img(IP_LIST[COUNT])
            IMG = ImageTk.PhotoImage(img)
            QR_CODE.config(image=IMG)
            QR_CODE.image = IMG  # keep a reference
            COUNT += 1
        else:
            tkinter.messagebox.showinfo('警告', '没啦！还不行检查手机电脑是否同处一个wifi')
            COUNT = 0
            CURRENT_IP.config(text=IP_LIST[COUNT])
            img = qrc_img(IP_LIST[COUNT])
            IMG = ImageTk.PhotoImage(img)
            QR_CODE.config(image=IMG)
            QR_CODE.image = IMG  # keep a reference
            COUNT += 1


def open_dir():
    filepath = os.path.join(os.path.dirname(os.path.abspath('__file__')), 'share_folder\\')
    if not os.path.exists(filepath):
        os.makedirs(filepath)
    os.system("start explorer %s" % filepath)


def about():
    msg = """开启服务后手机扫描显示的二维码等待页面打开，
页面打不开说明有多个网口，
需要切换二维码进行尝试。
进入页面查看电脑下的文件，点击文件名下载文件到手机。
选择手机页面中的上传文件将手机文件传到手机。"""
    tkinter.messagebox.showinfo(
        '使用说明',
        msg
    )


def connect():
    import webbrowser
    webbrowser.open("https://www.itprojects.cn/")


if __name__ == '__main__':
    root = Tk()
    # 设置主窗口标题
    root.title("局域网传输文件")
    # 设置窗口大小
    winWidth = 600
    winHeight = 400
    # 获取屏幕分辨率
    screenWidth = root.winfo_screenwidth()
    screenHeight = root.winfo_screenheight()
    x = int((screenWidth - winWidth) / 2)
    y = int((screenHeight - winHeight) / 2)
    # 设置窗口初始位置在屏幕居中
    root.geometry("%sx%s+%s+%s" % (winWidth, winHeight, x, y))
    # 设置窗口宽高固定
    root.resizable(0, 0)
    # 添加菜单栏
    menu = tkinter.Menu(root)
    root['menu'] = menu
    menu.add_command(label='关于', command=about)
    menu.add_command(label='更多项目', command=connect)
    # 增加背景图片
    bg = tk.PhotoImage(file="./img/no_bg.png")
    tk.Label(root, text="", justify=tk.LEFT, image=bg, compound=tk.CENTER).place(relx=0.8, rely=0.63, anchor=CENTER)

    IP_LIST, LEN_LIST = get_ip()

    Button(root, text='开启服务', command=start).place(relx=0.7, rely=0.08, anchor=CENTER)
    Button(root, text='更换网址', command=show_qrc).place(relx=0.8, rely=0.08, anchor=CENTER)
    Button(root, text='文件所在', command=open_dir).place(relx=0.9, rely=0.08, anchor=CENTER)

    QR_CODE = Label(root)
    QR_CODE.place(relx=0.3, rely=0.5, anchor=CENTER)
    CURRENT_IP = Label(root)
    CURRENT_IP.place(relx=0.3, rely=0.05, anchor=CENTER)

    root.mainloop()
