import parser
from math import factorial
from tkinter import Tk
from tkinter import Label
from tkinter import Entry
from tkinter import N, E, S, W
from tkinter import Button
from tkinter import END

DISPLAY = None
DISPLAY_INDEX = 0
PI = "3.14"


def display_cal_result(result):
    """显示计算结果"""
    global DISPLAY, DISPLAY_INDEX
    DISPLAY.delete(0, END)  # 删除之前显示的信息
    DISPLAY_INDEX = 0
    DISPLAY.insert(DISPLAY_INDEX, result)
    DISPLAY_INDEX += len(str(result))


def click_btn(operator_str):
    """
    对点击数字按钮或者功能按钮后要执行的代码进行封装
    相当于一个闭包
    """
    if operator_str == "=":
        def calculate():
            print("按下了=号按钮...")
            global DISPLAY
            # 获取显示器中当前所有的要计算的运算式
            operator_express = DISPLAY.get()
            try:
                operator_express_str = parser.expr(operator_express).compile()
                result = eval(operator_express_str)
                print("计算结果是:", result)
                display_cal_result(result)
            except Exception:
                print("计算出现错误...")

        return calculate
    elif operator_str == "x!":
        def num_factorial():
            global DISPLAY, DISPLAY_INDEX
            all_express_str = DISPLAY.get()
            try:
                result = factorial(int(all_express_str))
                # 删除之前显示的信息
                DISPLAY.delete(0, END)
                DISPLAY_INDEX = 0
                DISPLAY.insert(DISPLAY_INDEX, result)
            except Exception:
                # 删除之前显示的信息
                DISPLAY.delete(0, END)
                DISPLAY_INDEX = 0
                DISPLAY.insert(DISPLAY_INDEX, "Error")

        return num_factorial
    elif operator_str == "undo":
        def undo():
            global DISPLAY, DISPLAY_INDEX
            old_str = DISPLAY.get()
            if len(old_str):
                new_str = old_str[:-1]
                # 删除之前显示的信息
                DISPLAY.delete(0, END)
                DISPLAY_INDEX = 0
                # 插入去除最后1个之后的数据
                DISPLAY.insert(DISPLAY_INDEX, new_str)

        return undo
    elif operator_str == "AC":
        def clear_all():
            print("按下的是：", operator_str)
            global DISPLAY, DISPLAY_INDEX
            DISPLAY.delete(0, END)  # 删除之前显示的信息
            DISPLAY_INDEX = 0

        return clear_all
    elif operator_str in ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "+", "-", "*", "/", ".", PI, "%", "(", ")", "**", "**2"]:
        def handle():
            print("按下的是：", operator_str)
            # DISPLAY.insert(0, operator_str)
            global DISPLAY_INDEX
            DISPLAY.insert(DISPLAY_INDEX, operator_str)
            DISPLAY_INDEX += len(operator_str)

        return handle


def main():
    root = Tk()
    root.geometry("397x460")
    root.resizable(width=False, height=False)
    root.title('itprojects.cn - 计算器')

    Label(root, text="计算器", height=3, font=('Helvetica', '20', 'bold')).grid(row=0, columnspan=6, sticky=N + E + W + S)
    display = Entry(root, highlightcolor='red', highlightthickness=1, font=('Helvetica', '20', 'bold'))
    display.grid(row=1, columnspan=6, sticky=N + E + W + S)

    global DISPLAY
    DISPLAY = Entry(root, highlightcolor='red', highlightthickness=1, font=('Helvetica', '20', 'bold'))
    DISPLAY.grid(row=1, columnspan=6, sticky=N + E + W + S)

    # 创建键盘
    btn_height = 3
    btn_width = 8
    # 数字键盘
    Button(root, text="1", height=btn_height, width=btn_width, command=click_btn("1")).grid(row=2, column=0, sticky=N + S + E + W)
    Button(root, text=" 2", height=btn_height, width=btn_width, command=click_btn("2")).grid(row=2, column=1, sticky=N + S + E + W)
    Button(root, text=" 3", height=btn_height, width=btn_width, command=click_btn("3")).grid(row=2, column=2, sticky=N + S + E + W)
    Button(root, text="4", height=btn_height, width=btn_width, command=click_btn("4")).grid(row=3, column=0, sticky=N + S + E + W)
    Button(root, text=" 5", height=btn_height, width=btn_width, command=click_btn("5")).grid(row=3, column=1, sticky=N + S + E + W)
    Button(root, text=" 6", height=btn_height, width=btn_width, command=click_btn("6")).grid(row=3, column=2, sticky=N + S + E + W)
    Button(root, text="7", height=btn_height, width=btn_width, command=click_btn("7")).grid(row=4, column=0, sticky=N + S + E + W)
    Button(root, text=" 8", height=btn_height, width=btn_width, command=click_btn("8")).grid(row=4, column=1, sticky=N + S + E + W)
    Button(root, text=" 9", height=btn_height, width=btn_width, command=click_btn("9")).grid(row=4, column=2, sticky=N + S + E + W)

    # 功能键盘
    Button(root, text="AC", height=btn_height, width=btn_width, command=click_btn("AC")).grid(row=5, column=0, sticky=N + S + E + W)
    Button(root, text=" 0", height=btn_height, width=btn_width, command=click_btn("0")).grid(row=5, column=1, sticky=N + S + E + W)
    Button(root, text=" .", height=btn_height, width=btn_width, command=click_btn(".")).grid(row=5, column=2, sticky=N + S + E + W)
    Button(root, text="+", height=btn_height, width=btn_width, command=click_btn("+")).grid(row=2, column=3, sticky=N + S + E + W)
    Button(root, text="-", height=btn_height, width=btn_width, command=click_btn("-")).grid(row=3, column=3, sticky=N + S + E + W)
    Button(root, text="*", height=btn_height, width=btn_width, command=click_btn("*")).grid(row=4, column=3, sticky=N + S + E + W)
    Button(root, text="/", height=btn_height, width=btn_width, command=click_btn("/")).grid(row=5, column=3, sticky=N + S + E + W)
    Button(root, text="pi", height=btn_height, width=btn_width, command=click_btn(PI)).grid(row=2, column=4, sticky=N + S + E + W)
    Button(root, text="%", height=btn_height, width=btn_width, command=click_btn("%")).grid(row=3, column=4, sticky=N + S + E + W)
    Button(root, text="(", height=btn_height, width=btn_width, command=click_btn("(")).grid(row=4, column=4, sticky=N + S + E + W)
    Button(root, text="exp", height=btn_height, width=btn_width, command=click_btn("**")).grid(row=5, column=4, sticky=N + S + E + W)
    Button(root, text="<-", height=btn_height, width=btn_width, command=click_btn("undo")).grid(row=2, column=5, sticky=N + S + E + W)
    Button(root, text="x!", height=btn_height, width=btn_width, command=click_btn("x!")).grid(row=3, column=5, sticky=N + S + E + W)
    Button(root, text=")", height=btn_height, width=btn_width, command=click_btn(")")).grid(row=4, column=5, sticky=N + S + E + W)
    Button(root, text="^2", height=btn_height, width=btn_width, command=click_btn("**2")).grid(row=5, column=5, sticky=N + S + E + W)
    Button(root, text="=", height=btn_height, width=btn_width, command=click_btn("=")).grid(columnspan=6, sticky=N + S + E + W)

    root.mainloop()


if __name__ == '__main__':
    main()
