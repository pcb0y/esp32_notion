import time
import pygame
import random


class Score(object):
    # 创建文本对象，用来显示分数
    text_obj = None
    # 存储分数
    score = 0

    @classmethod
    def show(cls, screen):
        if cls.text_obj is None:
            cls.text_obj = pygame.font.SysFont("宋体", 50)

        text_score = cls.text_obj.render("score:%d" % cls.score, 1, (255, 255, 255))
        # 显示分数
        screen.blit(text_score, (0, 0))


class EnemyBullet(pygame.sprite.Sprite):
    # 创建精灵组（用来碰撞判断）
    sprite_group = pygame.sprite.Group()

    def __init__(self, x, y):
        super().__init__()
        # 创建一个图片，用来当做玩家发射的子弹
        self.image = pygame.image.load("./images/bullet1.png")
        # 创建子弹图片要显示的位置
        self.x, self.y = x, y
        # 设置尺寸; get_rect()可以获取图像的原始大小
        self.rect = self.image.get_rect()
        # 设置默认位置(这个位置用来碰撞检查)
        self.rect.x = self.x
        self.rect.y = self.y
        # 将当前对象添加到精灵组
        self.sprite_group.add(self)

    def move_and_show(self, screen):
        # 显示一个子弹
        screen.blit(self.image, (self.x, self.y))
        # 修改这个字典的位置，以便下次显示时 位置能够移动
        self.y += 10
        self.rect.y = self.y

    @classmethod
    def show_all(cls, screen):
        for temp in cls.sprite_group:
            temp.move_and_show(screen)

    @classmethod
    def clear(cls):
        """清空上次游戏留下的子弹"""
        cls.sprite_group = pygame.sprite.Group()


class EnemyPlane(pygame.sprite.Sprite):
    # 创建精灵组（用来碰撞判断）
    sprite_group = pygame.sprite.Group()
    # 创建另外一个精灵组（用来存放已经爆炸的飞机，展示爆炸效果）
    bomb_sprite_group = pygame.sprite.Group()
    # 创建一个列表用来记录爆炸时依次显示的效果图片
    bombed_pic_list = [pygame.image.load("./images/enemy0_down%d.png" % x) for x in range(1, 5)]
    # 当前飞机爆炸时的音效
    music = None

    def __init__(self):
        super().__init__()
        # 敌机图片
        self.image = pygame.image.load("./images/enemy0.png")
        # 初始位置
        self.x, self.y = random.randint(0, 480 - 51), random.randint(-400, -50)
        # 设置尺寸; get_rect()可以获取图像的原始大小
        self.rect = self.image.get_rect()
        # 设置默认位置(这个位置用来碰撞检查)
        self.rect.x = self.x
        self.rect.y = self.y
        # 默认速度
        self.speed = random.randint(1, 10)
        # 为每个敌机创建一个列表，用来存储这个敌机发射出去的子弹
        self.bullet_list = list()
        # 子弹发射冷却时间
        self.fire_cool_time = 0.3
        # 用来记录上次发射的时间
        self.last_fire_time = time.time()
        # 击中本架飞机，奖励给玩家的分数
        self.score = 50
        # 记录爆炸效果的计算开始时间
        self.bombed_time = time.time()
        # 记录当前显示的爆炸效果的图片的索引值（就是序号）
        self.bombed_pic_index = 0

    def show(self, screen):
        screen.blit(self.image, (self.x, self.y))

    def auto_move(self):
        # self.x += random.randint(0, 10)
        # self.y += random.randint(0, 10)
        self.y += self.speed
        self.rect.y = self.y
        # 判断飞机是否以及废除了底部边界，如果是那么就删除
        if self.rect.y >= 852:
            self.sprite_group.remove(self)

    def move_and_show(self, screen):
        self.auto_move()
        self.show(screen)
        # 让敌机发射子弹
        self.auto_fire()
        # 显示自己发射的所有子弹
        # for temp_bullet in self.bullet_list:
        #     # # 显示一个子弹
        #     # screen.blit(temp_bullet.image, (temp_bullet.x, temp_bullet.y))
        #     # # 修改这个字典的位置，以便下次显示时 位置能够移动
        #     # temp_bullet.y += 10
        #     temp_bullet.move_and_show(screen)

    def auto_fire(self):
        """敌机自动发射子弹"""
        # if time.time() - self.last_fire_time >= self.fire_cool_time:
        if time.time() - self.last_fire_time >= self.fire_cool_time and self.y >= 0:
            # self.bullet_list.append(EnemyBullet(self.x + 20, self.y + 40))
            # 创建新的敌机子弹对象
            new_enemy_bullet = EnemyBullet(self.x + 20, self.y + 40)
            self.bullet_list.append(new_enemy_bullet)
            # self.sprite_group.add(new_enemy_bullet)  # 将敌机子弹加入到精灵组
            self.last_fire_time = time.time()
            self.fire_cool_time = random.choice([0.3, 0.5, 0.7, 0.9, 1.0, 1.5, 2.0, 3.0, 3.5])

    def bombed(self):
        """
        本架飞机被击中
        :return:
        """
        self.bomb_sprite_group.add(self)
        # 从可以判断碰撞的精灵组中删除
        self.sprite_group.remove(self)
        # 播放敌机爆炸效果
        self.music_play()

    @classmethod
    def create_enemy_plane(cls):
        """
        定义一个类方法，用来批量创建敌机
        :return: None
        """
        # 判断当前有多少架飞机，如果少于2架，那么就创建新的5架
        if len(cls.sprite_group) > 2:
            return

        for i in range(5):
            # cls.enemy_plane_list.append(cls())
            # 创建敌机对象
            new_enemy_plane = cls()  # 创建敌机时x轴随机，这样敌机就不会堆在一块
            # cls.enemy_plane_list.append(new_enemy_plane)
            cls.sprite_group.add(new_enemy_plane)  # 将敌机加入到精灵组

    @classmethod
    def move_and_show_planes(cls, screen):
        """
        批量移动、显示敌机
        :return:
        """
        # for enemy_plane in cls.enemy_plane_list:
        for enemy_plane in cls.sprite_group:
            enemy_plane.move_and_show(screen)

    @classmethod
    def bomb_completed_check(cls):
        """
        检查爆炸效果是否完毕，如果未完毕则修改显示的图片
        :return:
        """
        for bombed_plane in cls.bomb_sprite_group:
            # 更新要显示的爆炸效果图片
            bombed_plane.image = cls.bombed_pic_list[bombed_plane.bombed_pic_index]

            if time.time() - bombed_plane.bombed_time > 0.2:
                # 爆炸效果时间已经过去0.2秒，那么就更换一张图片
                bombed_plane.bombed_time = time.time()
                bombed_plane.bombed_pic_index += 1
                if bombed_plane.bombed_pic_index >= len(cls.bombed_pic_list):
                    # 如果已经显示爆照效果图片到最后一张，那么就暂定在最后一张
                    # bombed_plane.bombed_pic_index -= 1
                    # 将这个精灵从精灵组中删除
                    cls.bomb_sprite_group.remove(bombed_plane)

            # 更新要显示的爆炸效果图片
            # bombed_plane.image = cls.bombed_pic_list[bombed_plane.bombed_pic_index]

    @classmethod
    def clear(cls):
        """清理上一次游戏的残留飞机"""
        cls.sprite_group = pygame.sprite.Group()

    @classmethod
    def music_init(cls):
        # 给类属性添加音乐，这样所有的子弹共用同一个音乐资源
        cls.music = pygame.mixer.Sound('./sound/enemy1_down.wav')
        # 当前 pygame 有些bug，如果不事先调用一次播放音乐，会导致真正需要方法爆炸音效时程序异常退出
        # 也就是说，正常情况下，如下的2行代码可以用一行cls.music.set_volume(0.3)来替代 表示设置音乐声音为0.3倍
        cls.music.set_volume(0.0)
        cls.music.play()

    @classmethod
    def music_play(cls):
        # 播放音乐
        cls.music.set_volume(0.3)
        cls.music.play()


class Bullet(pygame.sprite.Sprite):
    # 创建精灵组（用来碰撞判断）
    sprite_group = pygame.sprite.Group()
    # 存储这类弹发射后的音乐效果
    music = None

    def __init__(self, x, y):
        super().__init__()
        # 创建一个图片，用来当做玩家发射的子弹
        self.image = pygame.image.load("./images/bullet.png")
        # 创建子弹图片要显示的位置
        self.x, self.y = x, y
        # 设置尺寸; get_rect()可以获取图像的原始大小
        self.rect = self.image.get_rect()
        # 设置默认位置(这个位置用来碰撞检查)
        self.rect.x = self.x
        self.rect.y = self.y
        # 将玩家飞机子弹添加到精灵组
        self.sprite_group.add(self)
        # 创建这颗子弹时，播放音乐
        self.music_play()

    def move_and_show(self, screen):
        # 显示一个子弹
        screen.blit(self.image, (self.x, self.y))
        # 修改这个字典的位置，以便下次显示时 位置能够移动
        self.y -= 10
        self.rect.y = self.y

    @classmethod
    def show_all(cls, screen):
        """显示所有在精灵组中的子弹"""
        for temp in cls.sprite_group:
            temp.move_and_show(screen)

    @classmethod
    def clear(cls):
        """清理上次发射的子弹"""
        cls.sprite_group = pygame.sprite.Group()

    @classmethod
    def music_init(cls):
        # 给类属性添加音乐，这样所有的子弹共用同一个音乐资源
        cls.music = pygame.mixer.Sound('./sound/bullet.wav')
        # 当前 pygame 有些bug，如果不事先调用一次播放音乐，会导致真正需要方法爆炸音效时程序异常退出
        # 也就是说，正常情况下，如下的2行代码可以用一行cls.music.set_volume(0.3)来替代 表示设置音乐声音为0.3倍
        cls.music.set_volume(0.0)
        cls.music.play()

    @classmethod
    def music_play(cls):
        # 播放音乐
        cls.music.set_volume(0.3)
        cls.music.play()


class Hero(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # 创建一个图片，当做玩家控制的飞机
        self.image = pygame.image.load("./images/hero1.png")
        # 定义2变量，用来存储x、y坐标
        self.x, self.y = 480 / 2 - 100 / 2, 852 - 120 - 50
        # 创建一个列表，用来存储玩家发射的子弹对象
        # self.bullet_list = list()
        # 子弹发射冷却时间
        self.fire_cool_time = 0.3
        # 用来记录上次发射的时间
        self.last_fire_time = time.time()
        # 设置尺寸; get_rect()可以获取图像的原始大小
        self.rect = self.image.get_rect()
        # 设置默认位置(这个位置用来碰撞检查)
        self.rect.x = self.x
        self.rect.y = self.y

    def change_x_y(self):
        # 获取玩家按下的键
        key = pygame.key.get_pressed()
        if key[pygame.K_a] or key[pygame.K_LEFT]:
            print('按下了left键')
            self.x -= 10
            self.rect.x = self.x
        if key[pygame.K_d] or key[pygame.K_RIGHT]:
            print('按下了right键')
            self.x += 10
            self.rect.x = self.x
        if key[pygame.K_w] or key[pygame.K_UP]:
            print("按下了up键")
            self.y -= 10
            self.rect.y = self.y
        if key[pygame.K_s] or key[pygame.K_DOWN]:
            print("按下了down键")
            self.y += 10
            self.rect.y = self.y
        if key[pygame.K_SPACE]:
            print("按下了空格键")
            self.fire()

    def fire(self):
        """发射子弹"""
        if time.time() - self.last_fire_time >= self.fire_cool_time:
            self.last_fire_time = time.time()
            # 玩家每次按下空格键，就将当前玩家飞机的坐标组成一个元组添加到列表中，这个元组表示的含义是要显示的子弹的位置
            new_bullet_x, new_bullet_y = self.x + 40, self.y - 10
            # 创建一个子弹对象（同时把这个字典要显示的位置传入到__init__方法中）
            # new_bullet = Bullet(new_bullet_x, new_bullet_y)
            # self.bullet_list.append(new_bullet)  # 以为在第65行要修改元素的值，所以将元组改为列表。因为 元组不可变
            Bullet(new_bullet_x, new_bullet_y)

    def show(self, screen):
        # 将玩家飞机显示出来
        screen.blit(self.image, (self.x, self.y))  # 获取hero_x、hero_y的值，且将图片贴到这个坐标对应的位置

        # 遍历玩家飞机子弹列表，有多少个元素，就意味着有多少个子弹
        # for temp_bullet in self.bullet_list:
        #     temp_bullet.move_and_show(screen)

        # 显示所有玩家发射的子弹
        Bullet.show_all(screen)


def main(screen):
    # 播放背景音乐
    pygame.mixer.music.load('./sound/game_music.wav')
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1, 0.0)
    # 设置相关音乐
    Bullet.music_init()
    EnemyPlane.music_init()

    # 创建一个图片，当做游戏的背景图
    background = pygame.image.load("./images/background.png")

    # 每次新游戏时，将上一次的所有敌机、子弹清空
    EnemyPlane.clear()
    EnemyBullet.clear()
    Bullet.clear()

    # 创建一个飞机对象
    hero = Hero()

    # 批量创建敌机
    EnemyPlane.create_enemy_plane()

    # 创建计时器
    clock = pygame.time.Clock()

    # 通过无线循环让程序一直运行，而不是闪退
    while True:
        # 获取事件，比如按键等
        for event in pygame.event.get():
            # 判断是否是点击了退出按钮
            if event.type == pygame.QUIT:
                print("按下了退出键盘，exit")
                exit()  # 让整个程序结束，return让函数结束，break让循环结束

        # 控制玩家飞机
        hero.change_x_y()

        # 将背景图片贴到窗口中，这样才能显示（非常类似相片贴到相框中的关系）
        screen.blit(background, (0, 0))

        # 判断玩家飞机是否与敌机相碰撞
        if pygame.sprite.spritecollideany(hero, EnemyPlane.sprite_group):
            # exit("玩家飞机与敌机相碰撞，游戏结束")
            break

        # 判断玩家飞机是否与敌机子弹相碰撞
        if pygame.sprite.spritecollideany(hero, EnemyBullet.sprite_group):
            # exit("玩家飞机与敌机子弹相碰撞，游戏结束")
            break

        # 判断敌机是否与玩家发射子弹相碰撞
        # if pygame.sprite.groupcollide(EnemyPlane.sprite_group, Bullet.sprite_group, True, True):
        #     exit("敌机与玩家子弹相碰撞")
        ret = pygame.sprite.groupcollide(EnemyPlane.sprite_group, Bullet.sprite_group, True, True)
        if ret:
            # groupcollide检查碰撞之后，会返回字典（key是碰撞的EnemyPlane， value是碰撞的Bullet）
            for enemy_plane in ret.keys():
                print("score", enemy_plane.score)
                Score.score += enemy_plane.score  # 将击中的敌机的奖励分数加到游戏总分数
                enemy_plane.bombed()  # 这架飞机爆炸了
            print("敌机与玩家子弹相碰撞")

        # 显示玩家飞机以及发射的子弹
        hero.show(screen)

        # 自动生成新飞机
        EnemyPlane.create_enemy_plane()

        # 批量移动、显示敌机
        EnemyPlane.move_and_show_planes(screen)

        # 显示爆炸的敌机
        EnemyPlane.bomb_completed_check()
        EnemyPlane.bomb_sprite_group.draw(screen)

        # 显示敌机发射的子弹
        EnemyBullet.show_all(screen)

        # 显示分数
        Score.show(screen)

        # 更新需要显示的内容
        pygame.display.update()

        # FPS（每秒钟显示画面的次数）
        clock.tick(30)  # 通过一定的延时，实现1秒钟能够循环30次

    # 显示game over
    screen.blit(background, (0, 0))
    game_over = pygame.image.load("./images/gameover2.png")
    screen.blit(game_over, (0, 0))
    # 显示"重新开始"
    game_restart = pygame.image.load("./images/restart_nor.png")
    screen.blit(game_restart, (200, 500))
    # 显示"退出游戏"
    game_quit = pygame.image.load("./images/quit_nor.png")
    screen.blit(game_quit, (200, 600))
    pygame.display.update()
    pygame.mixer.music.stop()  # 停止之前的背景音乐
    pygame.mixer.music.load('./sound/game_over.wav')
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play()  # 播放游戏结束音乐
    while True:
        for event in pygame.event.get():
            # 判断是否是点击了退出按钮
            if event.type == pygame.QUIT:
                print("按下了退出键盘，exit")
                exit()  # 让整个程序结束，return让函数结束，break让循环结束
            # 判断是否点击了鼠标
            if pygame.mouse.get_pressed()[0]:
                # 提取x、y
                x, y = pygame.mouse.get_pos()
                # 判断是否点击了"重新开始"
                if 200 <= x <= 312 and 500 <= y <= 528:
                    print("重新开始游戏...")
                    return True
                elif 200 <= x <= 312 and 600 <= y <= 628:
                    print("退出游戏...")
                    exit()
        # FPS（每秒钟显示画面的次数）
        clock.tick(30)  # 通过一定的延时，实现1秒钟能够循环60次

        # time.sleep(0.01)


if __name__ == "__main__":
    # 对pygame进行必须要的初始化，否则字体等资源不能使用
    pygame.init()

    # 创建一个窗口，用来显示内容
    screen = pygame.display.set_mode((480, 852), 0, 32)

    while main(screen):
        pass
