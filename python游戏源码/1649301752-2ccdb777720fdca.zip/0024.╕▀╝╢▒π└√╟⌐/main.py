import sys
import time

from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

from MainWindow import Ui_MainWindow

# ///////////////////// 下面代码实现的功能：链接数据库定义ORM模型类等 ////////////////////
# 有了这个Base，我们可以依据这个Base定义任意数量的映射类(模型类)
Base = declarative_base()


class Note(Base):
    """定义Note模型类"""
    __tablename__ = 'note'
    id = Column(Integer, primary_key=True)
    text = Column(String(1000), nullable=False)
    x = Column(Integer, nullable=False, default=0)
    y = Column(Integer, nullable=False, default=0)


# 创建数据库引擎
engine = create_engine('sqlite:///notes.db')
# 如果第一次使用系统，没有数据库，那么下面一行代码就会自动创建，如果之前已经创建过，那么不会创建
Base.metadata.create_all(engine)

# 创建Session对象，以便执行需要的CURD操作
Session = sessionmaker(bind=engine)
session = Session()


# ///////////////////////// 下面代码功能：定义类实现Note创建的所有操作 ////////////////////
class MainWindow(QMainWindow, Ui_MainWindow):
    # 为了能够让创建出的note窗口对象引用计数不为0，所以用一个字典将其存储
    active_notes = dict()

    def __init__(self, *args, obj=None, **kwargs):
        # 调用父类的初始化
        super().__init__(*args, **kwargs)
        # 实现界面的设置
        self.setupUi(self)
        # 设置窗口的相关特性（隐藏窗口标题栏，且设置为最顶层的窗口）
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        # 显示当前note窗口
        self.show()

        if obj:
            # 如果创建此实例对象（即窗口对象）时传递了窗口对象，即obj不是None，此时加载它
            self.obj = obj
            self.load()
        else:
            # 否则话，就创建一个新的窗口，且存储它的位置
            self.obj = Note()
            self.save()

        # 绑定事件处理函数
        self.closeButton.pressed.connect(self.delete_window)
        self.moreButton.pressed.connect(lambda: self.create_new_note(self))
        self.textEdit.textChanged.connect(self.save)

        # 当前note窗口默认为未拖动
        self._drag_active = False
        # 记录上次拖动的位置
        self.previous_pos = None

        # 记录上次创建新Note窗口的时间
        self.last_create_note_time = time.time()

    @classmethod
    def create_new_note(cls, parent_note):
        """创建一个新的note窗口"""
        # 为了防止在鼠标点击"添加+"按钮时出现创建多个Note的错误情况，所以用时间判断的方式
        # 如果本次创建新Note与上次创建Note的间隔时间（即冷却时间）未到，则不能创建
        if time.time() - parent_note.last_create_note_time > 0.2:
            MainWindow()
            parent_note.last_create_note_time = time.time()

    def load(self):
        # 将当前窗口的位置设置到上次运行程序时的位置
        self.move(self.obj.x, self.obj.y)
        # 设置其内容为上次保存的内容
        self.textEdit.setHtml(self.obj.text)
        # 将当前窗口对象添加字典中以便更好的管理
        self.active_notes[self.obj.id] = self

    def save(self):
        # 将当前的note窗口的位置以及内容存储到db
        self.obj.x = self.x()
        self.obj.y = self.y()
        self.obj.text = self.textEdit.toHtml()
        session.add(self.obj)
        session.commit()
        self.active_notes[self.obj.id] = self

    def mousePressEvent(self, e):
        self.previous_pos = e.globalPos()

    def mouseMoveEvent(self, e):
        # 计算出当前鼠标拖动的位置相对于按下鼠标时的偏移量
        delta = e.globalPos() - self.previous_pos
        # 将当前note窗口进行移动
        self.move(self.x() + delta.x(), self.y() + delta.y())
        # 将当前移动后的新位置存储
        self.previous_pos = e.globalPos()
        # 标记为拖动进行中
        self._drag_active = True

    def mouseReleaseEvent(self, e):
        if self._drag_active:
            self.save()
            self._drag_active = False

    def delete_window(self):
        result = QMessageBox.question(self, "删除确认", "你确定真的要删除这个Note?")
        if result == QMessageBox.Yes:
            # 如果选择了删除，那么就讲这个数据从db中删除，且关闭此note窗口
            session.delete(self.obj)
            session.commit()
            self.close()


if __name__ == '__main__':
    # /////////////////// 下面代码实现共：创建应用程序，加载数据等 ///////////////////
    app = QApplication(sys.argv)
    app.setApplicationName("高级便利签")

    # 设置主题风格为Fusion
    app.setStyle("Fusion")

    # 创建一个配色对象，可以将窗口的显示颜色给修改
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(188, 170, 164))
    palette.setColor(QPalette.WindowText, QColor(121, 85, 72))
    palette.setColor(QPalette.ButtonText, QColor(121, 85, 72))
    palette.setColor(QPalette.Text, QColor(121, 85, 72))
    palette.setColor(QPalette.Base, QColor(188, 170, 164))
    palette.setColor(QPalette.AlternateBase, QColor(188, 170, 164))
    app.setPalette(palette)

    # 加载数据库中存储的note
    existing_notes = session.query(Note).all()
    if len(existing_notes) == 0:
        # 如果数据库中没有存储任何note，那么就创建一个
        MainWindow()
    else:
        for note in existing_notes:
            MainWindow(obj=note)

    app.exec_()
