import numpy
import constants


class HistoryTable:
    """历史启发算法"""

    def __init__(self):
        self.table = numpy.zeros((2, 90, 90))

    def get_history_score(self, who, step):
        return self.table[who, step.from_x * 9 + step.from_y, step.to_x * 9 + step.to_y]

    def add_history_score(self, who, step, depth):
        self.table[who, step.from_x * 9 + step.from_y, step.to_x * 9 + step.to_y] += 2 << depth


class Chess:
    def __init__(self, belong, chess_type):
        self.belong = belong  # 属于那方
        self.chess_type = chess_type  # 是什么棋

    def can_move(self, to_x, to_y):  # 返回能不能往哪个地方走
        return False


class Step:  # 走法类
    def __init__(self, from_x=-1, from_y=-1, to_x=-1, to_y=-1):
        self.from_x = from_x
        self.from_y = from_y
        self.to_x = to_x
        self.to_y = to_y
        self.score = 0

    def __cmp__(self, other):
        return self.score < other.score

    def __lt__(self, other):
        return self.score > other.score

    def __eq__(self, other):
        return self.score == other.score

    def __str__(self):
        return "[{}:{}]".format(self.__class__.__name__, ",".join("{}={}".format(k, getattr(self, k)) for k in self.__dict__.keys()))


class ChessBoard:
    def __init__(self):
        self.board = []  # 棋盘
        self.flag = False
        for i in range(9):
            self.board.append([])
            for j in range(10):
                if (constants.init_borad[i][j] == 0):
                    self.board[i].append(Chess(-1, constants.init_borad[i][j]))
                else:
                    self.board[i].append(Chess(0 if j < 5 else 1, constants.init_borad[i][j]))

    def print_board(self, flag=False):
        for i in range(9):
            strr = ""
            for j in range(10):
                strr = strr + " " + str(self.board[i][j].chess_type)
            print(strr)
        if flag:
            for i in range(9):
                strr = ""
                for j in range(10):
                    strr = strr + " " + str(self.board[i][j].belong)
                print(strr)

    def is_king_face_to_face(self, x, y, who):
        a = False
        if who == 1:
            for i in range(9, 6, -1):
                if self.board[x][i].chess_type == constants.jiang:
                    a = True
                    b = i
            if not a:
                return a
            for j in range(y + 1, b):
                if self.board[x][j].chess_type != constants.kong:
                    return False
            return b
        else:
            for i in range(0, 3):
                if self.board[x][i].chess_type == constants.jiang:
                    a = True
                    b = i
            if not a:
                return a
            for j in range(y - 1, b, -1):
                if self.board[x][j].chess_type != constants.kong:
                    return False
            return b

    def have_friend(self, x, y, who):
        if self.flag:
            return False
        if self.board[x][y].chess_type == 0:
            return False
        return self.board[x][y].belong == who

    def have_man(self, x, y):
        return self.board[x][y].chess_type != 0

    def generate_move(self, who):
        """返回所有可行的走法, 一个step类型的list"""
        res_list = []
        for x in range(9):
            for y in range(10):
                if self.board[x][y].chess_type != 0:
                    if self.board[x][y].belong != who:
                        continue
                    list2 = self.get_chess_move(x, y, who)
                    res_list = res_list + list2
        return res_list

    def get_chess_move(self, x, y, who, tag=False):
        """返回当前这个x、y标记的位置的棋子可以走棋的所有可能（已封装为Step对象）的列表"""
        self.flag = tag
        list3 = []
        if self.board[x][y].chess_type == 1 and who == 0:
            i = self.is_king_face_to_face(x, y, who)
            if i:
                list3.append(Step(x, y, x, i))
            # 纵向
            x1 = x
            # 向前
            y1 = y + 1
            if y1 <= 2 and (not self.have_friend(x1, y1, who)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 向后
            y1 = y - 1
            if y1 >= 0 and (not self.have_friend(x1, y1, who)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 横向
            y1 = y
            # 向左
            x1 = x - 1
            if x1 >= 3 and (not self.have_friend(x1, y1, who)) and self.is_king_face_to_face(x1, y1, who) == False:
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 向右
            x1 = x + 1
            if x1 <= 5 and (not self.have_friend(x1, y1, who)) and self.is_king_face_to_face(x1, y1, who) == False:
                s = Step(x, y, x1, y1)
                list3.append(s)
        elif self.board[x][y].chess_type == 1 and (not who == 0):
            i = self.is_king_face_to_face(x, y, who)
            if i:
                list3.append(Step(x, y, x, i))
            # 纵向
            x1 = x
            # 向前
            y1 = y - 1
            if y1 >= 7 and (not self.have_friend(x1, y1, who)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 向后
            y1 = y + 1
            if y1 <= 9 and (not self.have_friend(x1, y1, who)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 横向
            y1 = y
            # 向左
            x1 = x + 1
            if x1 <= 5 and (not self.have_friend(x1, y1, who)) and self.is_king_face_to_face(x1, y1, who) == False:
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 向右
            x1 = x - 1
            if x1 >= 3 and (not self.have_friend(x1, y1, who)) and self.is_king_face_to_face(x1, y1, who) == False:
                s = Step(x, y, x1, y1)
                list3.append(s)
        elif self.board[x][y].chess_type == 2 and (not who == 0):
            # 纵向
            x1 = x
            # 向前
            for y1 in range(y - 1, -1, -1):
                if self.have_man(x1, y1):
                    if not self.have_friend(x1, y1, who):
                        s = Step(x, y, x1, y1)
                        list3.append(s)
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 向后
            for y1 in range(y + 1, 10):
                if self.have_man(x1, y1):
                    if not self.have_friend(x1, y1, who):
                        s = Step(x, y, x1, y1)
                        list3.append(s)
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 横向
            y1 = y
            # 向左
            for x1 in range(x + 1, 9):
                if self.have_man(x1, y1):
                    if not self.have_friend(x1, y1, who):
                        s = Step(x, y, x1, y1)
                        list3.append(s)
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 向右
            for x1 in range(x - 1, -1, -1):
                if self.have_man(x1, y1):
                    if not self.have_friend(x1, y1, who):
                        s = Step(x, y, x1, y1)
                        list3.append(s)
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
        elif self.board[x][y].chess_type == 2 and who == 0:
            # 纵向
            x1 = x
            # 向前
            for y1 in range(y + 1, 10):
                if self.have_man(x1, y1):
                    if not self.have_friend(x1, y1, who):
                        s = Step(x, y, x1, y1)
                        list3.append(s)
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 向后
            for y1 in range(y - 1, -1, -1):
                if self.have_man(x1, y1):
                    if not self.have_friend(x1, y1, who):
                        s = Step(x, y, x1, y1)
                        list3.append(s)
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 横向
            y1 = y
            # 向左
            for x1 in range(x - 1, -1, -1):
                if self.have_man(x1, y1):
                    if not self.have_friend(x1, y1, who):
                        s = Step(x, y, x1, y1)
                        list3.append(s)
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 向右
            for x1 in range(x + 1, 9):
                if self.have_man(x1, y1):
                    if not self.have_friend(x1, y1, who):
                        s = Step(x, y, x1, y1)
                        list3.append(s)
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
        elif self.board[x][y].chess_type == 3 and who == 0:
            # x2,y2是用来判断是否有蹩脚的
            x2 = x + 1
            y2 = y
            if x2 <= 7 and (not self.have_man(x2, y2)):
                # 横着向右上
                y1 = y + 1
                x1 = x + 2
                if y1 <= 9 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
                # 横着向右下
                y1 = y - 1
                x1 = x + 2
                if y1 >= 0 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)

            x2 = x - 1
            y2 = y
            if x2 >= 1 and (not self.have_man(x2, y2)):
                # 横着向左上
                y1 = y + 1
                x1 = x - 2
                if y1 <= 9 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
                # 横着向左下
                y1 = y - 1
                x1 = x - 2
                if y1 >= 0 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)

            x2 = x
            y2 = y + 1
            if y2 <= 8 and (not self.have_man(x2, y2)):
                # 竖着向右上
                y1 = y + 2
                x1 = x + 1
                if x1 <= 8 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
                # 横着向左上
                y1 = y + 2
                x1 = x - 1
                if x1 >= 0 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)

            x2 = x
            y2 = y - 1
            if y2 >= 1 and (not self.have_man(x2, y2)):
                # 横着向右下
                y1 = y - 2
                x1 = x + 1
                if x1 <= 8 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
                # 横着向左下
                y1 = y - 2
                x1 = x - 1
                if x1 >= 0 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
        elif self.board[x][y].chess_type == 3 and (not who == 0):
            # x2,y2用来判断是否有蹩脚的
            x2 = x - 1
            y2 = y
            if x2 >= 1 and (not self.have_man(x2, y2)):
                # 横着向右上
                y1 = y - 1
                x1 = x - 2
                if y1 >= 0 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
                # 横着向右下
                y1 = y + 1
                x1 = x - 2
                if y1 <= 9 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)

            x2 = x + 1
            y2 = y
            if x2 <= 7 and (not self.have_man(x2, y2)):
                # 横着向左上
                y1 = y - 1
                x1 = x + 2
                if y1 >= 0 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
                # 横着向左下
                y1 = y + 1
                x1 = x + 2
                if y1 <= 9 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)

            x2 = x
            y2 = y + 1
            if y2 <= 8 and (not self.have_man(x2, y2)):
                # 竖着向右下
                y1 = y + 2
                x1 = x - 1
                if x1 >= 0 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
                # 横着向左下
                y1 = y + 2
                x1 = x + 1
                if x1 <= 8 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)

            x2 = x
            y2 = y - 1
            if y2 >= 1 and (not self.have_man(x2, y2)):
                # 横着向右上
                y1 = y - 2
                x1 = x - 1
                if x1 >= 0 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
                # 横着向左上
                y1 = y - 2
                x1 = x + 1
                if x1 <= 8 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
        elif self.board[x][y].chess_type == 4 and who == 0:
            # 纵向
            x1 = x
            # 向前
            for y1 in range(y + 1, 10):
                if self.have_man(x1, y1):
                    for y2 in range(y1 + 1, 10):
                        if (not self.have_friend(x1, y2, who)) and self.have_man(x1, y2):
                            s = Step(x, y, x1, y2)
                            list3.append(s)
                            break
                        if self.have_friend(x1, y2, who):
                            break
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 向后
            for y1 in range(y - 1, -1, -1):
                if self.have_man(x1, y1):
                    for y2 in range(y1 - 1, -1, -1):
                        if (not self.have_friend(x1, y2, who)) and self.have_man(x1, y2):
                            s = Step(x, y, x1, y2)
                            list3.append(s)
                            break
                        if self.have_friend(x1, y2, who):
                            break
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 横向
            y1 = y
            # 向左
            for x1 in range(x - 1, -1, -1):
                if self.have_man(x1, y1):
                    for x2 in range(x1 - 1, -1, -1):
                        if (not self.have_friend(x2, y1, who)) and self.have_man(x2, y1):
                            s = Step(x, y, x2, y1)
                            list3.append(s)
                            break
                        if self.have_friend(x2, y1, who):
                            break
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 向右
            for x1 in range(x + 1, 9):
                if self.have_man(x1, y1):
                    for x2 in range(x1 + 1, 9):
                        if (not self.have_friend(x2, y1, who)) and self.have_man(x2, y1):
                            s = Step(x, y, x2, y1)
                            list3.append(s)
                            break
                        if self.have_friend(x2, y1, who):
                            break
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
        elif self.board[x][y].chess_type == 4 and (not who == 0):
            # 纵向
            x1 = x
            # 向前
            for y1 in range(y - 1, -1, -1):
                if self.have_man(x1, y1):
                    for y2 in range(y1 - 1, -1, -1):
                        if (not self.have_friend(x1, y2, who)) and self.have_man(x1, y2):
                            s = Step(x, y, x1, y2)
                            list3.append(s)
                            break
                        if self.have_friend(x1, y2, who):
                            break
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 向后
            for y1 in range(y + 1, 10):
                if self.have_man(x1, y1):
                    for y2 in range(y1 + 1, 10):
                        if (not self.have_friend(x1, y2, who)) and self.have_man(x1, y2):
                            s = Step(x, y, x1, y2)
                            list3.append(s)
                            break
                        if self.have_friend(x1, y2, who):
                            break
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 横向
            y1 = y
            # 向左
            for x1 in range(x + 1, 9):
                if self.have_man(x1, y1):
                    for x2 in range(x1 + 1, 9):
                        if (not self.have_friend(x2, y1, who)) and self.have_man(x2, y1):
                            s = Step(x, y, x2, y1)
                            list3.append(s)
                            break
                        if self.have_friend(x2, y1, who):
                            break
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
            # 向右
            for x1 in range(x - 1, -1, -1):
                if self.have_man(x1, y1):
                    for x2 in range(x1 - 1, -1, -1):
                        if (not self.have_friend(x2, y1, who)) and self.have_man(x2, y1):
                            s = Step(x, y, x2, y1)
                            list3.append(s)
                            break
                        if self.have_friend(x2, y1, who):
                            break
                    break
                s1 = Step(x, y, x1, y1)
                list3.append(s1)
        elif self.board[x][y].chess_type == 5 and who == 0:
            # 向左上
            x1 = x - 2
            y1 = y + 2
            if y1 <= 4 and x1 >= 0 and (not self.have_friend(x1, y1, who)) and (not self.have_man(x - 1, y + 1)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 向右上
            x1 = x + 2
            y1 = y + 2
            if y1 <= 4 and x1 <= 8 and (not self.have_friend(x1, y1, who)) and (not self.have_man(x + 1, y + 1)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 向左下
            x1 = x - 2
            y1 = y - 2
            if y1 >= 0 and x1 >= 0 and (not self.have_friend(x1, y1, who)) and (not self.have_man(x - 1, y - 1)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 向右下
            x1 = x + 2
            y1 = y - 2
            if y1 >= 0 and x1 <= 8 and (not self.have_friend(x1, y1, who)) and (not self.have_man(x + 1, y - 1)):
                s = Step(x, y, x1, y1)
                list3.append(s)
        elif self.board[x][y].chess_type == 5 and (not who == 0):
            # 向左上
            x1 = x + 2
            y1 = y - 2
            if y1 >= 5 and x1 <= 8 and (not self.have_friend(x1, y1, who)) and (not self.have_man(x + 1, y - 1)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 向右上
            x1 = x - 2
            y1 = y - 2
            if y1 >= 5 and x1 >= 0 and (not self.have_friend(x1, y1, who)) and (not self.have_man(x - 1, y - 1)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 向左下
            x1 = x + 2
            y1 = y + 2
            if y1 <= 9 and x1 <= 8 and (not self.have_friend(x1, y1, who)) and (not self.have_man(x + 1, y + 1)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            # 向右下
            x1 = x - 2
            y1 = y + 2
            if y1 <= 9 and x1 >= 0 and (not self.have_friend(x1, y1, who)) and (not self.have_man(x - 1, y + 1)):
                s = Step(x, y, x1, y1)
                list3.append(s)
        elif self.board[x][y].chess_type == 6 and who == 0:
            if x == 3:
                if not self.have_friend(4, 1, who):
                    s = Step(x, y, 4, 1)
                    list3.append(s)
            elif x == 4:
                if not self.have_friend(3, 0, who):
                    s = Step(x, y, 3, 0)
                    list3.append(s)
                if not self.have_friend(3, 2, who):
                    s = Step(x, y, 3, 2)
                    list3.append(s)
                if not self.have_friend(5, 0, who):
                    s = Step(x, y, 5, 0)
                    list3.append(s)
                if not self.have_friend(5, 2, who):
                    s = Step(x, y, 5, 2)
                    list3.append(s)
            else:
                if not self.have_friend(4, 1, who):
                    s = Step(x, y, 4, 1)
                    list3.append(s)
        elif self.board[x][y].chess_type == 6 and (not who == 0):
            if x == 3:
                if not self.have_friend(4, 8, who):
                    s = Step(x, y, 4, 8)
                    list3.append(s)
            elif x == 4:
                if not self.have_friend(3, 9, who):
                    s = Step(x, y, 3, 9)
                    list3.append(s)
                if not self.have_friend(3, 7, who):
                    s = Step(x, y, 3, 7)
                    list3.append(s)
                if not self.have_friend(5, 9, who):
                    s = Step(x, y, 5, 9)
                    list3.append(s)
                if not self.have_friend(5, 7, who):
                    s = Step(x, y, 5, 7)
                    list3.append(s)
            else:
                if not self.have_friend(4, 8, who):
                    s = Step(x, y, 4, 8)
                    list3.append(s)
        elif self.board[x][y].chess_type == 7 and who == 0:
            # 向前
            x1 = x
            y1 = y + 1
            if y1 <= 9 and (not self.have_friend(x1, y1, who)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            if y >= 5:
                y1 = y
                # 向左
                x1 = x - 1
                if x1 >= 0 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
                # 向右
                x1 = x + 1
                if x1 <= 8 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
        elif self.board[x][y].chess_type == 7 and (not who == 0):
            # 向前
            x1 = x
            y1 = y - 1
            if y1 >= 0 and (not self.have_friend(x1, y1, who)):
                s = Step(x, y, x1, y1)
                list3.append(s)
            if y <= 4:
                y1 = y
                # 向左
                x1 = x + 1
                if x1 <= 8 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
                # 向右
                x1 = x - 1
                if x1 >= 0 and (not self.have_friend(x1, y1, who)):
                    s = Step(x, y, x1, y1)
                    list3.append(s)
        return list3


class Relation:
    def __init__(self):
        self.chess_type = 0

        self.num_attack = 0
        self.num_guard = 0
        self.num_attacked = 0
        self.num_guarded = 0

        self.attack = [0, 0, 0, 0, 0, 0]
        self.attacked = [0, 0, 0, 0, 0, 0]
        self.guard = [0, 0, 0, 0, 0, 0]
        self.guarded = [0, 0, 0, 0, 0, 0]


class Computer:
    def __init__(self):
        self.board = ChessBoard()  # 用于计算的棋盘
        self.max_depth = constants.max_depth
        self.history_table = HistoryTable()  # 历史启发算法
        self.best_move = Step()  # 创建一个"走法"对象，用来存储计算后要移动的棋子信息
        self.cnt = 0

    def alpha_beta(self, depth, alpha, beta):
        """alpha-beta剪枝，alpha是大可能下界，beta是最小可能上界"""
        # 1. 哪个玩家
        who = (self.max_depth - depth) % 2
        if self.is_game_over(who):  # 判断是否游戏结束，如果结束了就不用搜了
            return constants.min_val
        # 2. 搜到指定深度了，也不用搜了
        if depth == 1:
            return self.evaluate(who)
        # 3. 返回所有能走的方法
        move_list = self.board.generate_move(who)

        # 4.利用历史表，计算出每一步走棋的得分
        for i in range(len(move_list)):
            move_list[i].score = self.history_table.get_history_score(who, move_list[i])
        # 5. 为了让更容易剪枝利用历史表得分进行排序
        move_list.sort()  # 最终调用的__cmp__魔法方法

        best_step = move_list[0]
        score_list = []
        for step in move_list:
            # 假设走这1步棋
            temp = self.move_to(step)
            # 使用递归计算
            score = -self.alpha_beta(depth - 1, -beta, -alpha)  # 因为是一层选最大一层选最小，所以利用取负号来实现
            score_list.append(score)
            # 回退这一步棋
            self.undo_move(step, temp)

            # 更新分值，记录最优走棋
            if score > alpha:
                alpha = score
                if depth == self.max_depth:
                    self.best_move = step  # 记录最优走棋
                best_step = step
            # 找到最大值，立刻结束循环，提高速度
            if alpha >= beta:
                best_step = step
                break

        # 更新历史表
        if best_step.from_x != -1:
            self.history_table.add_history_score(who, best_step, depth)
        return alpha

    def evaluate(self, who):  # who表示该谁走，返回评分值
        self.cnt += 1
        relation_list = self.init_relation_list()
        base_val = [0, 0]
        pos_val = [0, 0]
        mobile_val = [0, 0]
        relation_val = [0, 0]
        for x in range(9):
            for y in range(10):
                now_chess = self.board.board[x][y]
                type = now_chess.chess_type
                if type == 0:
                    continue
                # now = 0 if who else 1
                now = now_chess.belong
                pos = x * 9 + y
                temp_move_list = self.board.get_chess_move(x, y, now, True)
                # 计算基础价值
                base_val[now] += constants.base_val[type]
                # 计算位置价值
                if now == 0:  # 如果是要求最大值的玩家
                    pos_val[now] += constants.pos_val[type][pos]
                else:
                    pos_val[now] += constants.pos_val[type][89 - pos]
                # 计算机动性价值，记录关系信息
                for item in temp_move_list:
                    # print('----------------')
                    # print(item)
                    temp_chess = self.board.board[item.to_x][item.to_y]  # 目的位置的棋子

                    if temp_chess.chess_type == constants.kong:  # 如果是空，那么加上机动性值
                        # print('ok')
                        mobile_val[now] += constants.mobile_val[type]
                        # print(mobile_val[now])
                        continue
                    elif temp_chess.belong != now:  # 如果不是自己一方的棋子
                        # print('ok1')
                        if temp_chess.chess_type == constants.jiang:  # 如果能吃了对方的将，那么就赢了
                            if temp_chess.belong != who:
                                # print(self.board.board[item.from_x][item.from_y])
                                # print(temp_chess)
                                # print(item)
                                # print('bug here')
                                return constants.max_val
                            else:
                                relation_val[1 - now] -= 20  # 如果不能，那么就相当于被将军，对方要减分
                                continue
                        # 记录攻击了谁
                        relation_list[x][y].attack[relation_list[x][y].num_attack] = temp_chess.chess_type
                        relation_list[x][y].num_attack += 1
                        relation_list[item.to_x][item.to_y].chess_type = temp_chess.chess_type

                        relation_list[item.to_x][item.to_y].attacked[
                            relation_list[item.to_x][item.to_y].num_attacked] = type
                        relation_list[item.to_x][item.to_y].num_attacked += 1
                    elif temp_chess.belong == now:
                        # print('ok2')
                        if temp_chess.chess_type == constants.jiang:  # 保护自己的将没有意义，直接跳过
                            continue
                        relation_list[x][y].guard[relation_list[x][y].num_guard] = temp_chess
                        relation_list[x][y].num_guard += 1
                        relation_list[item.to_x][item.to_y].chess_type = temp_chess.chess_type
                        relation_list[item.to_x][item.to_y].guarded[relation_list[item.to_x][item.to_y].num_guarded] = type
                        relation_list[item.to_x][item.to_y].num_guarded += 1
                    # relation_list[x][y].chess_type = type
        for x in range(9):
            for y in range(10):
                num_attacked = relation_list[x][y].num_attacked
                num_guarded = relation_list[x][y].num_guarded
                now_chess = self.board.board[x][y]
                type = now_chess.chess_type
                now = now_chess.belong
                unit_val = constants.base_val[now_chess.chess_type] >> 3
                sum_attack = 0  # 被攻击总子力
                sum_guard = 0
                min_attack = 999  # 最小的攻击者
                max_attack = 0  # 最大的攻击者
                max_guard = 0
                flag = 999  # 有没有比这个子的子力小的
                if type == constants.kong:
                    continue
                # 统计攻击方的子力
                for i in range(num_attacked):
                    temp = constants.base_val[relation_list[x][y].attacked[i]]
                    flag = min(flag, min(temp, constants.base_val[type]))
                    min_attack = min(min_attack, temp)
                    max_attack = max(max_attack, temp)
                    sum_attack += temp
                # 统计防守方的子力
                for i in range(num_guarded):
                    temp = constants.base_val[relation_list[x][y].guarded[i]]
                    max_guard = max(max_guard, temp)
                    sum_guard += temp
                if num_attacked == 0:
                    relation_val[now] += 5 * relation_list[x][y].num_guarded
                else:
                    muti_val = 5 if who != now else 1
                    if num_guarded == 0:  # 如果没有保护
                        relation_val[now] -= muti_val * unit_val
                    else:  # 如果有保护
                        if flag != 999:  # 存在攻击者子力小于被攻击者子力,对方将愿意换子
                            relation_val[now] -= muti_val * unit_val
                            relation_val[1 - now] -= muti_val * (flag >> 3)
                        # 如果是二换一, 并且最小子力小于被攻击者子力与保护者子力之和, 则对方可能以一子换两子
                        elif num_guarded == 1 and num_attacked > 1 and min_attack < constants.base_val[type] + sum_guard:
                            relation_val[now] -= muti_val * unit_val
                            relation_val[now] -= muti_val * (sum_guard >> 3)
                            relation_val[1 - now] -= muti_val * (flag >> 3)
                        # 如果是三换二并且攻击者子力较小的二者之和小于被攻击者子力与保护者子力之和,则对方可能以两子换三子
                        elif num_guarded == 2 and num_attacked == 3 and sum_attack - max_attack < constants.base_val[type] + sum_guard:
                            relation_val[now] -= muti_val * unit_val
                            relation_val[now] -= muti_val * (sum_guard >> 3)
                            relation_val[1 - now] -= muti_val * ((sum_attack - max_attack) >> 3)
                        # 如果是n换n，攻击方与保护方数量相同并且攻击者子力小于被攻击者子力与保护者子力之和再减去保护者中最大子力,则对方可能以n子换n子
                        elif num_guarded == num_attacked and sum_attack < constants.base_val[now_chess.chess_type] + sum_guard - max_guard:
                            relation_val[now] -= muti_val * unit_val
                            relation_val[now] -= muti_val * ((sum_guard - max_guard) >> 3)
                            relation_val[1 - now] -= sum_attack >> 3

        my_max_val = base_val[0] + pos_val[0] + mobile_val[0] + relation_val[0]
        my_min_val = base_val[1] + pos_val[1] + mobile_val[1] + relation_val[1]
        if who == 0:
            return my_max_val - my_min_val
        else:
            return my_min_val - my_max_val

    def init_relation_list(self):
        res_list = []
        for i in range(9):
            res_list.append([])
            for j in range(10):
                res_list[i].append(Relation())
        return res_list

    def move_to(self, step):
        """移动棋子"""
        # 1. 得到要移动的棋子属于哪一方
        belong = self.board.board[step.to_x][step.to_y].belong
        # 2. 得到要移动的棋子是什么
        chess_type = self.board.board[step.to_x][step.to_y].chess_type
        # 3. 创建一个棋子对象
        temp = Chess(belong, chess_type)
        # 4. 将棋子落到新位置
        self.board.board[step.to_x][step.to_y].chess_type = self.board.board[step.from_x][step.from_y].chess_type
        self.board.board[step.to_x][step.to_y].belong = self.board.board[step.from_x][step.from_y].belong
        # 5. 旧位置标记为空
        self.board.board[step.from_x][step.from_y].chess_type = constants.kong
        self.board.board[step.from_x][step.from_y].belong = -1

        return temp

    def undo_move(self, step, chess):
        """恢复棋子"""
        self.board.board[step.from_x][step.from_y].belong = self.board.board[step.to_x][step.to_y].belong
        self.board.board[step.from_x][step.from_y].chess_type = self.board.board[step.to_x][step.to_y].chess_type
        self.board.board[step.to_x][step.to_y].belong = chess.belong
        self.board.board[step.to_x][step.to_y].chess_type = chess.chess_type

    def is_game_over(self, who):  # 判断游戏是否结束
        for i in range(9):
            for j in range(10):
                if self.board.board[i][j].chess_type == constants.jiang:
                    if self.board.board[i][j].belong == who:
                        return False
        return True


if __name__ == "__main__":
    game = Computer()
    while True:
        from_x = int(input())
        from_y = int(input())
        to_x = int(input())
        to_y = int(input())
        s = Step(from_x, from_y, to_x, to_y)
        game.move_to(s)
        # game.board.print_board()

        game.alpha_beta(game.max_depth, constants.min_val, constants.max_val)
        print(game.best_move)
        game.move_to(game.best_move)

    game.move_to(s)
