import os

from PyQt5 import QtWidgets, QtCore
from PyQt5.QtWidgets import QFileDialog, QMessageBox, QMainWindow

from image_mark import Ui_MainWindow
from PIL import Image, ImageDraw, ImageFont, ImageEnhance


class ImageWindow(Ui_MainWindow, QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowFlags(QtCore.Qt.WindowCloseButtonHint)  # 只显示关闭按钮
        self.setupUi(self)  # 初始化窗体设置

    def get_font_size(self):
        """获取字体大小"""
        return self.fontSize.value()

    # 是否为图片
    def isImg(self, file):
        file = file.lower()
        if file == '.jpg':
            return True
        elif file == '.png':
            return True
        elif file == '.jpeg':
            return True
        elif file == '.bmp':
            return True
        else:
            return False

    # 获取所有文件
    def getFiles(self):
        try:
            # 选择图片文件夹路径
            self.img_path = QFileDialog.getExistingDirectory(None, "选择图片文件夹路径", os.getcwd())
            self.list = os.listdir(self.img_path)  # 遍历选择的文件夹
            num = 0  # 记录图片数量
            self.listWidget.clear()  # 清空列表项
            for i in range(0, len(self.list)):  # 遍历图片列表
                filepath = os.path.join(self.img_path, self.list[i])  # 记录遍历到的文件名
                if os.path.isfile(filepath):  # 判断是否为文件
                    imgType = os.path.splitext(filepath)[1]  # 获取扩展名
                    if self.isImg(imgType):  # 判断是否为图片
                        num += 1  # 数量加1
                        self.item = QtWidgets.QListWidgetItem(self.listWidget)  # 创建列表项
                        self.item.setText(self.list[i])  # 显示图片列表
            self.statusBar.showMessage('共有图片 ' + str(num) + ' 张')  # 显示图片总数
        except Exception:
            QMessageBox.warning(None, '警告', '请选择一个有效路径……', QMessageBox.Ok)

    # 预览图片
    def itemClick(self, item):
        os.startfile(self.img_path + '\\' + item.text())

    # 选择水印图片
    def setImg(self):
        try:
            # waterimg即为选择的水印图片，第二形参为对话框标题，第三个为对话框打开后默认的路径
            self.waterimg = QFileDialog.getOpenFileName(None, '选择水印图片', 'C:\\', "图片文件(*.jpeg;*.png;*.jpg;*.bmp)")
            self.lineEdit_2.setText(self.waterimg[0])  # 显示选择的水印图片
        except Exception as e:
            print(e)

    # 选择保存路径
    def msg(self):
        try:
            # dir_path即为选择的文件夹的绝对路径，第二形参为对话框标题，第三个为对话框打开后默认的路径
            self.dir_path = QFileDialog.getExistingDirectory(None, "选择路径", os.getcwd())
            self.lineEdit_3.setText(self.dir_path)  # 显示选择的保存路径
        except Exception as e:
            print(e)

    # 文字水印
    def textMark(self, img, newImgPath):
        im = Image.open(img).convert('RGBA')  # 打开原始图片，并转换为RGBA
        newImg = Image.new('RGBA', im.size, (255, 255, 255, 0))  # 存储添加水印后的图片
        font = ImageFont.truetype('simkai.ttf', self.get_font_size())
        imagedraw = ImageDraw.Draw(newImg)  # 创建绘制对象
        imgwidth, imgheight = im.size  # 记录图片大小

        # 计算右边距
        def is_chinese(word):
            for ch in word:
                if '\u4e00' <= ch <= '\u9fff':
                    return True
            return False

        chinese_charactor_num = 0
        for temp in self.lineEdit.text():
            if is_chinese(temp):
                chinese_charactor_num += 1

        # 获取字体宽度（中文字体的宽度与字母数字的宽度不一样，所以需要计算出其数量）
        txtwidth = self.get_font_size() * chinese_charactor_num + self.get_font_size() // 2 * (len(self.lineEdit.text()) - chinese_charactor_num)
        txtheight = self.get_font_size()  # 获取字体高度

        # 设置水印文字位
        if self.comboBox.currentText() == '左上角':
            position = (0, 0)
        elif self.comboBox.currentText() == '左下角':
            position = (0, imgheight - txtheight)
        elif self.comboBox.currentText() == '右上角':
            position = (imgwidth - txtwidth, 0)
        elif self.comboBox.currentText() == '右下角':
            position = (imgwidth - txtwidth, imgheight - txtheight)
        elif self.comboBox.currentText() == '居中':
            position = ((imgwidth - txtwidth) // 2, (imgheight - txtheight) // 2)
        # 设置文本颜色
        imagedraw.text(position, self.lineEdit.text(), font=font, fill="#FCA454")
        # 设置透明度
        alpha = newImg.split()[3]
        alpha = ImageEnhance.Brightness(alpha).enhance(int(self.horizontalSlider.value()) / 10.0)
        newImg.putalpha(alpha)
        Image.alpha_composite(im, newImg).save(newImgPath)  # 保存图片

    # 图片水印
    def imgMark(self, img, newImgPath):
        im = Image.open(img)  # 打开原始图片
        mark = Image.open(self.lineEdit_2.text())  # 打开水印图片
        rgbaim = im.convert('RGBA')  # 将原始图片转换为RGBA
        rgbamark = mark.convert('RGBA')  # 将水印图片转换为RGBA
        imgwidth, imgheight = rgbaim.size  # 获取原始图片尺寸
        nimgwidth, nimgheight = rgbamark.size  # 获取水印图片尺寸
        # 缩放水印图片
        scale = 10
        markscale = max(imgwidth / (scale * nimgwidth), imgheight / (scale * nimgheight))
        newsize = (int(nimgwidth * markscale), int(nimgheight * markscale))  # 计算新的尺寸大小
        rgbamark = rgbamark.resize(newsize, resample=Image.ANTIALIAS)  # 重新设置水印图片大小
        nimgwidth, nimgheight = rgbamark.size  # 获取水印图片缩放后的尺寸
        # 计算水印位置
        if self.comboBox.currentText() == '左上角':
            position = (0, 0)
        elif self.comboBox.currentText() == '左下角':
            position = (0, imgheight - nimgheight)
        elif self.comboBox.currentText() == '右上角':
            position = (imgwidth - nimgwidth, 0)
        elif self.comboBox.currentText() == '右下角':
            position = (imgwidth - nimgwidth, imgheight - nimgheight)
        elif self.comboBox.currentText() == '居中':
            position = (int(imgwidth / 2), int(imgheight / 2))
        # 设置透明度：img.point(function)接受一个参数，且对图片中的每一个点执行这个函数，这个函数是一个匿名函数，使用lambda表达式来完成
        # convert()函数，用于不同模式图像之间的转换，模式“L”为灰色图像，它的每个像素用8个bit表示，0表示黑，255表示白，其他数字表示不同的灰度。
        # 在PIL中，从模式“RGB”转换为“L”模式是按照下面的公式转换的：L = R * 299/1000 + G * 587/1000+ B * 114/1000
        rgbamarkpha = rgbamark.convert("L").point(lambda _: int(self.horizontalSlider.value() / 10 * 255))
        rgbamark.putalpha(rgbamarkpha)
        # 水印位置
        rgbaim.paste(rgbamark, position, rgbamarkpha)
        rgbaim.save(newImgPath)  # 保存水印图片

    # 添加水印
    def addMark(self):
        if self.lineEdit_3.text() == '':  # 判断是否选择了保存路径
            QMessageBox.warning(None, '警告', '请选择保存路径', QMessageBox.Ok)
            return
        else:
            try:
                num = 0  # 记录处理图片数量
                for i in range(0, self.listWidget.count()):  # 遍历图片列表
                    # 设置原始图片路径（包括文件名）
                    filepath = os.path.join(self.img_path, self.listWidget.item(i).text())
                    # 设置水印图片保存路径（包括文件名）
                    newfilepath = os.path.join(self.lineEdit_3.text(), self.listWidget.item(i).text())
                    if self.radioButton.isChecked():  # 判断是否选择文字水印单选按钮
                        if self.lineEdit.text() == '':  # 判断是否输入了水印文字
                            QMessageBox.warning(None, '警告', '请输入水印文字', QMessageBox.Ok)
                            return
                        else:
                            self.textMark(filepath, newfilepath)  # 调用textMark方法添加文字水印
                            num += 1  # 处理图片数量加1
                    else:
                        if self.lineEdit_2.text() != '':  # 判断水印图片不为空
                            self.imgMark(filepath, newfilepath)  # 调用imgMark方法添加图片水印
                            num += 1  # 处理图片数量加1
                        else:
                            QMessageBox.warning(None, '警告', '请选择水印图片', QMessageBox.Ok)
                statusBar_info = '任务完成，此次共处理 ' + str(num) + ' 张图片'
                self.statusBar.showMessage(statusBar_info)  # 显示处理图片总数
                QMessageBox.warning(None, '完成', statusBar_info, QMessageBox.Ok)
            except Exception:
                QMessageBox.warning(None, '错误', '图片格式有误，请重新选择……', QMessageBox.Ok)
