import sys
from PyQt5.QtWidgets import QApplication, QStyleFactory

from imageRename import Ui_RenameWindow

"""
命令提示：
1. UI文件转换为Py文件
    pyuic5 -o xxxx.py xxxx.ui
2. 打包为exe
    pyinstaller -F -w xxxx.py
    参数说明：
    –icon=图标路径
    -F 打包成一个exe文件
    -w 使用窗口，无控制台
    -c 使用控制台，无窗口
    -D 创建一个目录，里面包含exe以及其他一些依赖性文件
    pyinstaller -h 来查看参数
"""

if __name__ == '__main__':
    app = QApplication(sys.argv)

    # 设置窗口窗口风格
    QApplication.setStyle(QStyleFactory.create("Fusion"))
    # print(QStyleFactory.keys())  # 查看可以设置的风格

    window = Ui_RenameWindow()
    window.show()

    sys.exit(app.exec())
