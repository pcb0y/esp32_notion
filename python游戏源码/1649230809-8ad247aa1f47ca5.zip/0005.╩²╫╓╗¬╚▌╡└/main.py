import sys
import random
import pygame

# 窗口的宽高
WIDTH, HEIGHT = (414, 414)


def random_board_nums():
    """
    得到一个随机的棋盘
    """
    nums = [x for x in range(9)]  # [0, 1, 2, 3, 4, 5, 6, 7, 8]
    random.shuffle(nums)  # 乱序，此时nums是乱的
    return [list(x) for x in zip(*[iter(nums)] * 3)]  # 例如[[3, 5, 8], [6, 1, 0], [2, 4, 7]]


def is_win(board_list_temp):
    # 判断是否获胜
    # 获胜时的棋盘数字位置
    board_list = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 0]
    ]

    return board_list == board_list_temp


def move_up(board_list_temp):
    # 定义变量，存储找到的空白位置的列树
    col = 0
    # 找出列数
    for row, line in enumerate(board_list_temp):
        try:
            col = line.index(0)
            break
        except Exception:
            pass
    # 判断是否在第最后1行，如果不是则交换
    if row != len(board_list_temp) - 1:
        board_list_temp[row + 1][col], board_list_temp[row][col] = board_list_temp[row][col], board_list_temp[row + 1][col]


def move_down(board_list_temp):
    # 定义变量，存储找到的空白位置的列树
    col = 0
    # 找出列数
    for row, line in enumerate(board_list_temp):
        try:
            col = line.index(0)
            break
        except Exception:
            pass
    # 判断是否在第1行，如果不是则交换
    if row != 0:
        board_list_temp[row - 1][col], board_list_temp[row][col] = board_list_temp[row][col], board_list_temp[row - 1][col]


def move_left(board_list_temp):
    for row, line in enumerate(board_list_temp):
        # 对每一行进行的操作如下：
        # 1. 查询0出现的下标（索引index），如果没有则会产生异常，如果有则会正常
        # 2. 如果当前行有数字0，那么就判断是否在最右边，如果不在最右边，那么就可以移动一个棋子
        try:
            index = line.index(0)
            if index != len(line) - 1:
                line[index], line[index + 1] = line[index + 1], line[index]
        except Exception:
            pass


def move_right(board_list_temp):
    for row, line in enumerate(board_list_temp):
        # 对每一行进行的操作如下：
        # 1. 查询0出现的下标（索引index），如果没有则会产生异常，如果有则会正常
        # 2. 如果当前行有数字0，那么就判断是否在最左边，如果不在最左边，那么就可以移动一个棋子
        try:
            index = line.index(0)
            if index != 0:
                line[index], line[index - 1] = line[index - 1], line[index]
        except Exception:
            pass


def move(direction, board_list_temp):
    if direction == "left":
        print("left测试")
        move_left(board_list_temp)
    elif direction == "right":
        print("right测试")
        move_right(board_list_temp)
    elif direction == "up":
        print("up测试")
        move_up(board_list_temp)
    elif direction == "down":
        print("down测试")
        move_down(board_list_temp)


def main():
    # 游戏初始化
    pygame.init()
    pygame.display.set_caption("数字华容道")
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    board_img = pygame.image.load("./resource/board.png")
    win_img = pygame.image.load("./resource/win.png")
    # 数字与图片对应
    num_img_dict = {
        0: pygame.image.load("./resource/blank.png"),
        1: pygame.image.load("./resource/1.png"),
        2: pygame.image.load("./resource/2.png"),
        3: pygame.image.load("./resource/3.png"),
        4: pygame.image.load("./resource/4.png"),
        5: pygame.image.load("./resource/5.png"),
        6: pygame.image.load("./resource/6.png"),
        7: pygame.image.load("./resource/7.png"),
        8: pygame.image.load("./resource/8.png"),
    }
    # 9宫格(数字0表示的空位置)
    # board_list = [
    #     [1, 2, 3],
    #     [4, 5, 6],
    #     [7, 8, 0]
    # ]
    board_list = random_board_nums()
    # 标记获胜
    win_flag = False
    # 重来一局的点击范围
    x_min, y_min = 138, 204
    x_max, y_max = 270, 227

    # 创建计时器（防止while循环过快，占用太多CPU的问题）
    clock = pygame.time.Clock()
    while True:
        # 事件检测（鼠标点击、键盘按下等）
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key in [pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT]:
                    direction = {pygame.K_UP: 'up', pygame.K_DOWN: 'down', pygame.K_LEFT: 'left', pygame.K_RIGHT: 'right'}[event.key]
                    print("按下了方向键:", direction)
                    move(direction, board_list)
                    if is_win(board_list):
                        print("获胜")
                        win_flag = True
            elif not win_flag and event.type == pygame.MOUSEBUTTONDOWN and event.button:
                # 游戏过程中可以通过鼠标点击移动
                click_row, click_col = 0, 0  # 点击的数字的坐标
                blank_row, blank_col = 0, 0  # 空白处位置的坐标
                # 先计算出鼠标点击的是哪一个数字，row以及col是多少
                x, y = pygame.mouse.get_pos()
                for row, line in enumerate(board_list):
                    for col, num in enumerate(line):
                        if 12 + 130 * col <= x <= 12 + 130 * (col + 1) and 12 + 130 * row <= y <= 12 + 130 * (row + 1):
                            print("点击的是第{}行,第{}列，当前数字是{}".format(row, col, num))
                            click_row, click_col = row, col
                        if num == 0:
                            blank_row, blank_col = row, col

                # 根据计算出的点击位置，看看应该向哪个方向移动
                if (click_row, click_col) != (blank_row, blank_col):  # 判断点击的是否是空白位置，如果不是则继续
                    if (click_row - blank_row) ** 2 + (click_col - blank_col) ** 2 == 1:  # 如果点击的位置与空白位置相邻，那么就继续
                        direction = ""
                        if click_row == blank_row:
                            if click_col < blank_col:
                                print("向右移动")
                                direction = "right"
                            else:
                                print("向左移动")
                                direction = "left"
                        else:
                            if click_row < blank_row:
                                print("向下移动")
                                direction = "down"
                            else:
                                print("向上移动")
                                direction = "up"

                        move(direction, board_list)
                        if is_win(board_list):
                            print("获胜")
                            win_flag = True

            elif win_flag and event.type == pygame.MOUSEBUTTONDOWN and event.button:
                x, y = pygame.mouse.get_pos()
                if x_min <= x <= x_max and y_min <= y <= y_max:
                    print("点击了再来一局")
                    win_flag = False
                    board_list = random_board_nums()

        # 添加黑色
        screen.fill(pygame.Color("#000000"))

        # 显示背景
        screen.blit(board_img, (0, 0))

        # 显示数字
        for row, line in enumerate(board_list):
            for col, num in enumerate(line):
                screen.blit(num_img_dict[num], (12 + 130 * col, 12 + 130 * row))

        # 显示获胜
        if win_flag:
            screen.blit(win_img, (100, 100))

        # 刷新显示（此时窗口才会真正的显示）
        pygame.display.update()
        # FPS（每秒钟显示画面的次数）
        clock.tick(60)  # 通过一定的延时，实现1秒钟能够循环60次


if __name__ == '__main__':
    main()
